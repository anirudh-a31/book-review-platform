/**
 * Replaces backslashes with one forward slash
 * @param input
 */
declare function forwardSlash(input: string): string;
export default forwardSlash;
