declare function getSymbolDescription(thisArg: symbol | Symbol): string | undefined;

export = getSymbolDescription;