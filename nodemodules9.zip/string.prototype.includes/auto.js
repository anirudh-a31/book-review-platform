/*! https://mths.be/includes v2.0.0 by @mathias */

'use strict';

require('./shim')();
