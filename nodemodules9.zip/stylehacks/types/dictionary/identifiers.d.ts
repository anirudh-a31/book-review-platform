export const MEDIA_QUERY: "media query";
export const PROPERTY: "property";
export const SELECTOR: "selector";
export const VALUE: "value";
