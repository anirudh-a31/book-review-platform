export const BODY: "body";
export const HTML: "html";
