export const FF_2: "firefox 2";
export const IE_5_5: "ie 5.5";
export const IE_6: "ie 6";
export const IE_7: "ie 7";
export const IE_8: "ie 8";
export const OP_9: "opera 9";
