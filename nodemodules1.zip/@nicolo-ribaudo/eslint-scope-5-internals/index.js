"use strict";

module.exports = {
    ...require("eslint-scope"),
    Definition: require("eslint-scope/lib/definition").Definition,
    PatternVisitor: require("eslint-scope/lib/pattern-visitor"),
    Referencer: require("eslint-scope/lib/referencer"),
};
