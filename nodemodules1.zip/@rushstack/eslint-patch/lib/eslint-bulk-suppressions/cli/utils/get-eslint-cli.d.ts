export declare function getEslintPath(packagePath: string): string;
//# sourceMappingURL=get-eslint-cli.d.ts.map