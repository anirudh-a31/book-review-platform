// src/pages/Home.js
import React from 'react';
import { Link } from 'react-router-dom';

const Home = () => {
    // Sample book data
    const books = [
        {
            id: 1,
            title: "The Great Gatsby",
            author: "F. Scott Fitzgerald",
            description: "A novel set in the Roaring Twenties that tells the story of Jay Gatsby's unrequited love for Daisy Buchanan."
        },
        {
            id: 2,
            title: "To Kill a Mockingbird",
            author: "Harper Lee",
            description: "A novel about the serious issues of rape and racial inequality, narrated by a young girl named Scout Finch."
        },
        {
            id: 3,
            title: "1984",
            author: "George Orwell",
            description: "A dystopian novel that explores the dangers of totalitarianism and extreme political ideology."
        },
        {
            id: 4,
            title: "Pride and Prejudice",
            author: "Jane Austen",
            description: "A romantic novel that critiques the British landed gentry at the end of the 18th century."
        }
    ];

    return (
        <div>
            <h1>Welcome to the Book Review Platform</h1>
            <nav>
                <ul>
                    <li>
                        <Link to="/books">Book Listing</Link>
                    </li>
                    <li>
                        <Link to="/profile">User  Profile</Link>
                    </li>
                </ul>
            </nav>
            <h2>Featured Books</h2>
            <ul>
                {books.map(book => (
                    <li key={book.id}>
                        <h3>{book.title}</h3>
                        <p><strong>Author:</strong> {book.author}</p>
                        <p>{book.description}</p>
                    </li>
                ))}
            </ul>
        </div>
    );
};

export default Home;