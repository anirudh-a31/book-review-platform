import React from 'react';

const BookListing = () => {
    return <h1>Book Listing Page</h1>;
};

export default BookListing; // Ensure this is a default export