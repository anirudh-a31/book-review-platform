import React from 'react';

const UserProfilePage = () => {
    return <h1>User Profile Page</h1>;
};

export default UserProfilePage; // Ensure this is a default export